# General Advantage Estimation

Install via pip:

```bash
pip install gae
```

